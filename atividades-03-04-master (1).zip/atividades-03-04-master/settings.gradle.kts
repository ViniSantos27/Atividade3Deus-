rootProject.name = "atividades"
