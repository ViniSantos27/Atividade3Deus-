package br.org.fundatec.lpIII.atividades.service;

import br.org.fundatec.lpIII.atividades.model.Address;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@Service
public class CepAbertoService implements CepService {
    @Override
    public Address searchByCep(String cep) {
        try {
            HttpClient httpClient = HttpClient.newHttpClient();
            String cepAbertoUrl = "https://www.cepaberto.com/api/v3/cep?cep=" + cep;
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(cepAbertoUrl))
                    .header("Authorization", "Token token=21e77485e82bf19d0fba79125e8a75ff")
                    .build();

            HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (httpResponse.statusCode() == 200) {
                String responseBody = httpResponse.body();
                Address address = new Address();
                address.setCep(extractValue(responseBody, "cep"));
                address.setStreet(extractValue(responseBody, "logradouro"));
                address.setCity(extractValue(responseBody, "cidade"));
                address.setState(extractValue(responseBody, "estado"));
                address.setApi(extractValue(responseBody, "cepaberto"));

                return address;
            } else {
                throw new RuntimeException("Erro ao fazer a requisição à API CepAberto. Código de status: " + httpResponse.statusCode());
            }
        } catch (Exception e) {
            throw new RuntimeException("Erro ao fazer a requisição à API CepAberto: " + e.getMessage());
        }
    }

    private String extractValue(String responseBody, String field) {
        int index = responseBody.indexOf(field);
        if (index != -1) {
            int startIndex = responseBody.indexOf(":", index) + 1;
            int endIndex = responseBody.indexOf(",", startIndex);
            if (endIndex == -1) {
                endIndex = responseBody.indexOf("}", startIndex);
            }
            return responseBody.substring(startIndex, endIndex).replaceAll("\"", "").trim();
        }
        throw new RuntimeException("Campo '" + field + "' não encontrado na resposta da API.");
    }
}
