package br.org.fundatec.lpIII.atividades.service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import br.org.fundatec.lpIII.atividades.model.Address;
import br.org.fundatec.lpIII.atividades.repository.BrasilApiResponseDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service
@Primary
public class BrasilApiService implements CepService {

    private static final String API_URL = "https://brasilapi.com.br/api/cep/v1/";
    private final ObjectMapper objectMapper;

    public BrasilApiService() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Override
    public Address searchByCep(String cep) {
        try {
            HttpClient httpClient = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_URL + cep))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                String responseBody = response.body();
                return mapJsonToDto(responseBody);
            } else {
                throw new RuntimeException("Erro ao fazer a requisição à API. Código de status: " + response.statusCode());
            }
        } catch (Exception e) {
            throw new RuntimeException("Erro ao fazer a requisição à API: " + e.getMessage());
        }
    }

    private Address mapJsonToDto(String json) {
        try {
            BrasilApiResponseDTO brasilApiResponseDTO = objectMapper.readValue(json, BrasilApiResponseDTO.class);
            Address address = new Address();
            address.setCep(brasilApiResponseDTO.getCep());
            address.setStreet(brasilApiResponseDTO.getStreet());
            address.setCity(brasilApiResponseDTO.getCity());
            address.setState(brasilApiResponseDTO.getState());
            address.setCity(brasilApiResponseDTO.getCity());




            return address;
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Erro ao mapear JSON para objeto: " + e.getMessage());
        }
    }
}
