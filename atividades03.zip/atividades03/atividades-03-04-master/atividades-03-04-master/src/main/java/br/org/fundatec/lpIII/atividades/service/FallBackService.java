package br.org.fundatec.lpIII.atividades.service;
import br.org.fundatec.lpIII.atividades.model.Address;
import lombok.RequiredArgsConstructor;
import java.util.List;



    @RequiredArgsConstructor
    class FallBackService implements CepService {
        private List<String> fallbackOrder;
        private List<CepService> external =
                List.of(
                        new CepAbertoService(),
                        new BrasilApiService(),
                        new ViaCepService()
                );

        @Override
        public Address searchByCep(String cep) {

            Address response = null;
            for (CepService externalService : external) {
                try {
                    response = externalService.searchByCep(cep);
                    break;
                } catch (RuntimeException ex) {
                    continue;
                }
            }
            return response;
        }

    }

