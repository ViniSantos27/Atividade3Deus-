package br.org.fundatec.lpIII.atividades.service;



import br.org.fundatec.lpIII.atividades.model.Address;
import br.org.fundatec.lpIII.atividades.repository.ViaCepResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service

public class ViaCepService implements CepService {

    private final RestTemplate restTemplate = new RestTemplate();


    @Override
    public Address searchByCep(String cep) {
        String viaCepUrl = "https://viacep.com.br/ws/" + cep + "/json/";
        ViaCepResponseDTO viaCepResponseDTO = restTemplate.getForObject(viaCepUrl, ViaCepResponseDTO.class);
        if (viaCepResponseDTO != null) {
            return mapToAddress(viaCepResponseDTO);
        }
        return null;
    }

    private Address mapToAddress(ViaCepResponseDTO viaCepResponseDTO) {
        Address address = new Address();
        address.setCep(viaCepResponseDTO.getCep());
        address.setStreet(viaCepResponseDTO.getLogradouro());
        address.setCity(viaCepResponseDTO.getLocalidade());
        address.setState(viaCepResponseDTO.getUf());
        return address;
    }
}
