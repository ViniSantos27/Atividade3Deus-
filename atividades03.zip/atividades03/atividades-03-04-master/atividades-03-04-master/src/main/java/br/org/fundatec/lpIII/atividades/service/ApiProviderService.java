package br.org.fundatec.lpIII.atividades.service;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
public class ApiProviderService {


    @Service
    public class CepServiceProvider {
        @Autowired
        private CepService viaCepService;

        @Autowired
        private CepService brasilApiService;

        @Autowired
        private CepService cepAbertoService;

        @Value("${app.cep.api}")
        private String cepApiProvider;

        private final Map<String, CepService> cepServiceMap = new HashMap<>();

        @PostConstruct
        private void initializeCepServiceMap() {
            cepServiceMap.put("VIACEP", viaCepService);
            cepServiceMap.put("BRASILAPI", brasilApiService);
            cepServiceMap.put("CEPABERTO", cepAbertoService);
        }

        public CepService getCepService() {
            CepService cepService = cepServiceMap.get(cepApiProvider.toUpperCase());
            if (cepService == null) {
                throw new IllegalArgumentException("Provedor de API de CEP não suportado: " + cepApiProvider);
            }
            return cepService;
        }
    }

}
