package br.org.fundatec.lpIII.atividades.model;



import lombok.Data;

@Data

public class Address {


    private String cep;
    private String street;
    private String city;
    private String state;

    public String getApi() {
        return api;
    }

    public void setApi(String api) {
        this.api = api;
    }

    private String api;


    public Address() {
    }





    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }




    }
