package br.org.fundatec.lpIII.atividades.repository;
import br.org.fundatec.lpIII.atividades.model.Address;

import java.util.ArrayList;
import java.util.List;




    class AddressRepository {
        private List<Address> addressList;

        public AddressRepository() {

            addressList = new ArrayList<>();

            addressList.add(new Address());
            addressList.add(new Address());

        }

        public Address findByCep(String cep) {

            for (Address address : addressList) {
                if (address.getCep().equals(cep)) {
                    return address;
                }
            }

            return null;
        }
    }



