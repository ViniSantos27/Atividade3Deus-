package br.org.fundatec.lpIII.atividades.service;


import br.org.fundatec.lpIII.atividades.model.Address;
public abstract class ExternalCepService {


    public abstract Address searchByCep(String cep);

    public interface ExternalCepRestService {
        Address searchByCep(String cep);


    }


}
