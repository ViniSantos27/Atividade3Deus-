package br.org.fundatec.lpIII.atividades.repository;

import  lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BrasilApiResponseDTO {

    private String cep;
    private  String logradouro;
    private  String complemento;
    private  String street;
    private String localidade;
    private String state;
    private String ibge;
    private  String city;


}
