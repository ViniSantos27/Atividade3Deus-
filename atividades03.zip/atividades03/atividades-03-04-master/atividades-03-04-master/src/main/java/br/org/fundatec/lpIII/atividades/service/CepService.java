package br.org.fundatec.lpIII.atividades.service;


import br.org.fundatec.lpIII.atividades.model.Address;
import org.springframework.stereotype.Service;

@Service
public interface CepService {

    Address searchByCep(String cep);
}